package com.cg.hibernate;

public class Marvels {

	private String movie;
	private int yearofRelease;
	private int rating;
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	public int getYearofRelease() {
		return yearofRelease;
	}
	public void setYearofRelease(int yearofRelease) {
		this.yearofRelease = yearofRelease;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}


}
