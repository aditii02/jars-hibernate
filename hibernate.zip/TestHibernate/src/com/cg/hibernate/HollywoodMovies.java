package com.cg.hibernate;

import org.hibernate.cfg.Configuration;

public class HollywoodMovies {
	public static void main(String[] args) {

		Marvels movie = new Marvels();
		movie.setMovie("Captain America");
		movie.setRating(7);
		movie.setYearofRelease(2011);
		
		Configuration config =  new Configuration();

	}

}
